package org.java.springmvc.dao;

import org.java.springmvc.model.MvcForm;

public interface MvcDao {
void getStudList(MvcForm mvcForm);
void insertStudList(MvcForm mvcForm);
void getStudListBySno(MvcForm mvcForm);
void getStudDeleteBySno(MvcForm mvcForm);


}
