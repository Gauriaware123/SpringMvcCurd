package org.java.springmvc.dao.impl;

import java.util.List;


import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.java.springmvc.dao.MvcDao;
import org.java.springmvc.model.MvcForm;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class MvcDaoImpl implements MvcDao{
	
   @Autowired	
   private SessionFactory sessionFactory;

   public void setSessionFactory(SessionFactory sessionFactory) {
	   this.sessionFactory = sessionFactory;
    }
   @Override
   public void getStudList(MvcForm mvcForm) {
   Session session = sessionFactory.openSession();
   Criteria criteria = session.createCriteria(MvcForm.class);
   criteria.addOrder(Order.asc("sno"));
   List<MvcForm> studList = criteria.list();
   mvcForm.setStudList(studList);
   session .close();
   }
   @Override
   public void insertStudList(MvcForm mvcForm) {
   Session session = sessionFactory.openSession();
   Transaction transaction = session.beginTransaction();
   session.saveOrUpdate(mvcForm);
   transaction.commit();
}
@Override
public void getStudListBySno(MvcForm mvcForm){
	Session session = sessionFactory.openSession();
	 Criteria criteria = session.createCriteria(MvcForm.class);
	 Criterion criterion = Restrictions.eq("sno", mvcForm.getSno());
	 criteria.add(criterion);
	 
	MvcForm mvc=(MvcForm)criteria.uniqueResult();
	mvcForm.setSname(mvc.getSname());
	mvc.setAge(mvc.getAge());
	 
}
@Override
public void getStudDeleteBySno(MvcForm mvcForm) {
	Session session = sessionFactory.openSession();
	Transaction transaction=session.beginTransaction();
	
	session.delete(mvcForm);		
	
	transaction.commit();
}

}
