package org.java.springmvc.dto;

import java.util.List;

import org.java.springmvc.model.MvcForm;

public class MvcDto {
	private int sno;
	private String sname;
	private int age;
	private List<MvcForm> studList;
	public int getSno() {
		return sno;
	}
	public void setSno(int sno) {
		this.sno = sno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public List<MvcForm> getStudList() {
		return studList;
	}
	public void setStudList(List<MvcForm> studList) {
		this.studList = studList;
	}
	
}
