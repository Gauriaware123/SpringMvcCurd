package org.java.springmvc.service.impl;

import java.util.List;

import org.java.springmvc.dao.MvcDao;
import org.java.springmvc.dto.MvcDto;
import org.java.springmvc.model.MvcForm;
import org.java.springmvc.service.MvcService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MvcServiceImpl implements MvcService{
    @Autowired
	private MvcDao mvcDao;

	public void setMvcDao(MvcDao mvcDao) {
		this.mvcDao = mvcDao;
	}
	@Override
	public void getStudListService(MvcDto mvcDto) {
    		MvcForm mvcForm  =	new	MvcForm();
    		mvcDao.getStudList(mvcForm);
    		List<MvcForm> studList =  mvcForm.getStudList();
    		mvcDto.setStudList(studList);	
	}
	@Override
	public void insertStudService(MvcDto mvcDto) {
		MvcForm mvcForm  =	new	MvcForm();
		mvcForm.setSno(mvcDto.getSno());
		mvcForm.setSname(mvcDto.getSname());
		mvcForm.setAge(mvcDto.getAge());
		
		mvcDao.insertStudList(mvcForm);
	}
	@Override
	public void getStudByListService(MvcDto mvcDto) {
		 MvcForm mvcForm = new MvcForm();
		 
		 mvcForm.setSno(mvcDto.getSno());
		 
		 mvcDao.getStudListBySno(mvcForm);
		 
		 mvcDto.setSname(mvcForm.getSname());
		 mvcDto.setAge(mvcForm.getAge());
		 
	}
	@Override
	public void getStudDeleteBySnoService(MvcDto mvcDto) {
		 MvcForm mvcForm = new MvcForm();
		 mvcForm.setSno(mvcDto.getSno());
		 mvcDao.getStudDeleteBySno(mvcForm);
	}
  
}
