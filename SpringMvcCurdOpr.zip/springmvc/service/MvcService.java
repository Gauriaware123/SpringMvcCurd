package org.java.springmvc.service;

import org.java.springmvc.dto.MvcDto;

public interface MvcService {
void getStudListService(MvcDto mvcDto);
void insertStudService(MvcDto mvcDto);
void getStudByListService(MvcDto mvcDto);
void getStudDeleteBySnoService(MvcDto mvcDto);

}
