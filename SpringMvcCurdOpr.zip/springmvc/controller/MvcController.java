package org.java.springmvc.controller;

import java.util.List;

import org.java.springmvc.dto.MvcDto;
import org.java.springmvc.model.MvcForm;
import org.java.springmvc.service.MvcService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class MvcController {
 
	@Autowired
	private MvcService mvcSerive;
	
	public void setMvcSerive(MvcService mvcSerive) {
		this.mvcSerive = mvcSerive;
	}
    
	@RequestMapping(value="list.htm")
	public String getStudListCtrl(Model model)
	{
		MvcDto mvcDto = new MvcDto();
		mvcSerive.getStudListService(mvcDto);
		List<MvcForm> studList = mvcDto.getStudList();
		
		model.addAttribute("sList",studList);
		 
		return "list";
	}
	@RequestMapping(value="add.htm")
	public String getMaxSnoCtrl()
	{
		return "add";
	}
	
	@RequestMapping(value="insert.htm")
	public String insertStudListCtrl(@RequestParam(value="sno")int sno, @RequestParam(value="sname")String sname,@RequestParam(value="age")int age)
	{
		MvcDto mvcDto = new MvcDto();
		
		mvcDto.setSno(sno);
		mvcDto.setSname(sname);
		mvcDto.setAge(age);
		
		mvcSerive.insertStudService(mvcDto);
		
		return "redirect:list.htm";
	}
	
	@RequestMapping(value="update.htm")
	public String getStudBySnoCtrl(@RequestParam(value="sno")int sno,Model model)
	{
		MvcDto mvcDto=new MvcDto();
		mvcDto.setSno(sno);
		mvcSerive.getStudByListService(mvcDto);
		model.addAttribute("sno",mvcDto.getSno());
		model.addAttribute("sname",mvcDto.getSname());
		model.addAttribute("age",mvcDto.getAge());
		return "update";
	}
	
	@RequestMapping(value="delete.htm")
	public String getStudDeleteBysno(@RequestParam(value="sno") int sno)
	{
		MvcDto mvcDto=new MvcDto();
		mvcDto.setSno(sno);
		mvcSerive.getStudDeleteBySnoService(mvcDto);
		
		return "redirect:list.htm";
	}
	

}
