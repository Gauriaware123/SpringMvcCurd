package org.java.springmvc.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="STUDENTTABLE")
public class MvcForm {
    @Id
	private int sno;
	private String sname;
	private int age;
	
	@Transient
	private List<MvcForm> studList;

	public int getSno() {
		return sno;
	}

	public void setSno(int sno) {
		this.sno = sno;
	}

	public String getSname() {
		return sname;
	}

	public void setSname(String sname) {
		this.sname = sname;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public List<MvcForm> getStudList() {
		return studList;
	}

	public void setStudList(List<MvcForm> studList) {
		this.studList = studList;
	}
	
	
}
